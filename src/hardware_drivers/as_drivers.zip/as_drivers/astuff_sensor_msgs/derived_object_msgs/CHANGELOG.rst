^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package derived_object_msgs
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

4.0.0 (2023-04-24)
------------------

3.3.0 (2021-06-18)
------------------

3.2.0 (2021-03-12)
------------------

3.1.0 (2020-06-17)
------------------
* Remove CipvTrack message and radar_msgs dependency (`#62 <https://github.com/astuff/astuff_sensor_msgs/issues/62>`_)
* Contributors: icolwell-as

3.0.1 (2020-01-23)
------------------
* Adding ros_environment as required package to all packages.
* Hybridize derived_object_msgs. (`#44 <https://github.com/astuff/astuff_sensor_msgs/issues/44>`_)
* Adding hybrid CI.
* Updating package.xml files for ROS2 rosdep.
* Adding message migration rules.
* Contributors: Joshua Whitley

2.3.1 (2018-12-07)
------------------
* Merge pull request `#31 <https://github.com/astuff/astuff_sensor_msgs/issues/31>`_ from astuff/maint/add_urls
* Adding URLs to package.xml files.
* Contributors: Daniel-Stanek, Joshua Whitley

2.3.0 (2018-10-04)
------------------

2.2.2 (2018-08-30)
------------------

2.2.1 (2018-08-08)
------------------
* Renamed perception_msgs to derived_object_msgs for clarification.
* Moving perception_msgs from platform_automation_msgs.
* Contributors: Joe Buckner, Joshua Whitley
